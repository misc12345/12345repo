﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT Misc Videos
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTmisc'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

# Entry point
def run():
    plugintools.log("YTmisc.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("YTmisc.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="VideoRevealed",
        url="plugin://plugin.video.youtube/channel/UCfzAdXeniYhIGlFndHYPiYg/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7-hua06LGagDtyHkfYXzVvPz2bGjfdtseMAKg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Adobe in a Minute",
        url="plugin://plugin.video.youtube/channel/UCCOCVxg0ZiLo6GQ0xctkM7g/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l795YKq4BkC_mOS0AT9gxV-kdlNYqriw23WLbg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Adobe Photoshop Tutorial : The Basics for Beginners",
        url="plugin://plugin.video.youtube/play/?video_id=pFyOznL9UvA",
        thumbnail="",
        folder=False )        		
        
    plugintools.add_item( 
        #action="", 
        title="PiXimperfect",
        url="plugin://plugin.video.youtube/channel/UCMrvLMUITAImCHMOhX88PYQ/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7_16JD9ZpxhTpeamyuJfL3x-lna6OBvHrsVIQ=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		        
    plugintools.add_item( 
        #action="", 
        title="How to Transform PHOTOS into Gorgeous, Pencil DRAWINGS",
        url="plugin://plugin.video.youtube/play/?video_id=K43-_zhQZiM",
        thumbnail="",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="Turn Your Photo into Sketch Easily in Photoshop!",
        url="plugin://plugin.video.youtube/play/?video_id=hJuP5RVTdVw",
        thumbnail="",
        folder=False )
        
    plugintools.add_item( 
        #action="", 
        title="How to convert a photo to cartoon using Photoshop",
        url="plugin://plugin.video.youtube/play/?video_id=e2klKMj4JEw",
        thumbnail="",
        folder=False )
        
    plugintools.add_item( 
        #action="", 
        title="一个视频剪辑的好工具",
        url="plugin://plugin.video.youtube/play/?video_id=NMMrVOAI3Q0",
        thumbnail="",
        folder=False )
       
    plugintools.add_item( 
        #action="", 
        title="D.I.Y Softbox from Cardboard",
        url="plugin://plugin.video.youtube/play/?video_id=FCONVzE8XJQ",
        thumbnail="",
        folder=False )
        
    plugintools.add_item( 
        #action="", 
        title="FactoFusion - Magic Secrets Revealed",
        url="plugin://plugin.video.youtube/channel/UCd-1pQG-2H5IJl4Jkmy3bXw/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7_tEs0rU1vM-cRxAJRUGgDrV5IkxVP388RePg=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Gabriel St-Germain - Shopify Dropshipping",
        url="plugin://plugin.video.youtube/channel/UCqw27ZfS4aWdNhP1MDOldPA/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7_w0A7K9qIgURPOEGZx3IsOUSuU9o0iaeta9A=s288-c-k-c0xffffffff-no-rj-mo",
        folder=True )
		
run()