﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# YT Music 2
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.YTmusic2'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

# Entry point
def run():
    plugintools.log("YTmusic2.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("YTmusic2.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="Piano In 21 Days",
        url="plugin://plugin.video.youtube/channel/UCY_UFcJ5Mktc1fH1SNQwrUQ/",
        thumbnail="https://yt3.ggpht.com/-HnFVquKQugs/AAAAAAAAAAI/AAAAAAAAAAA/-vKIerhM5MI/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg",
        folder=True )
        	
    plugintools.add_item( 
        #action="", 
        title="Lypur Piano-Theory",
        url="plugin://plugin.video.youtube/channel/UCpzgTNTgQsR9YYsyOm3k3KQ/",
        thumbnail="https://yt3.ggpht.com/-1KyjFXrXOvk/AAAAAAAAAAI/AAAAAAAAAAA/h6vqXQ-DI5s/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="PlayPianoTODAY.com",
        url="plugin://plugin.video.youtube/channel/UCA-oSxA0_mTwtvEdOX4yMdA/",
        thumbnail="https://www.playpianotoday.com/images/play-piano-today-logo_segno.png",
        folder=True )
		        
    plugintools.add_item( 
        #action="", 
        title="Learn piano in 10 lessons",
        url="plugin://plugin.video.youtube/user/danthecomposer/",
        thumbnail="https://yt3.ggpht.com/-bS0JaBhU1rw/AAAAAAAAAAI/AAAAAAAAAAA/Y26mWoChix0/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="The Online Piano and Violin Tutor",
        url="plugin://plugin.video.youtube/user/theonlinepianotutor/",
        thumbnail="https://yt3.ggpht.com/-6h1R3UqbjE4/AAAAAAAAAAI/AAAAAAAAAAA/GzBJZ8gN4DA/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="ImprovPianoTips",
        url="plugin://plugin.video.youtube/user/ImprovPianoTips/",
        thumbnail="https://yt3.ggpht.com/-2m0gbpt80dA/AAAAAAAAAAI/AAAAAAAAAAA/jmsVzjyotpQ/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="InstantPianoGenius",
        url="plugin://plugin.video.youtube/user/InstantPianoGenius/",
        thumbnail="https://yt3.ggpht.com/-TKw8d4JevQA/AAAAAAAAAAI/AAAAAAAAAAA/NvPGW0VxoXk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
       
    plugintools.add_item( 
        #action="", 
        title="JustinGuitar Songs",
        url="plugin://plugin.video.youtube/channel/UCcZd_G62wtsCXd-b7OhQdlw/",
        thumbnail="https://yt3.ggpht.com/-J5JjwMbMlbg/AAAAAAAAAAI/AAAAAAAAAAA/79T6mW1XlKU/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="JustinGuitar",
        url="plugin://plugin.video.youtube/channel/UCBNkm8o5LiEVLxO8w0p2sfQ/",
        thumbnail="https://yt3.ggpht.com/-5lZN4lWqIJ4/AAAAAAAAAAI/AAAAAAAAAAA/OTjz43hchDk/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="MyTwangyGuitar",
        url="plugin://plugin.video.youtube/user/MyTwangyGuitar/",
        thumbnail="https://yt3.ggpht.com/-gyXJb8NWsdM/AAAAAAAAAAI/AAAAAAAAAAA/xxpA9QXdgAM/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )
 
    plugintools.add_item( 
        #action="", 
        title="Shutup & Play",
        url="plugin://plugin.video.youtube/channel/UCAwuvzhah0KUw5QNihSkEwQ/",
        thumbnail="https://yt3.ggpht.com/a/AGF-l7_JFfWodMR50UkfIBtBXdeSPqh4VAFcjUZT5A=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )
 
    plugintools.add_item( 
        #action="", 
        title="Six String Country",
        url="plugin://plugin.video.youtube/user/sixstringcountryhd/",
        thumbnail="https://yt3.ggpht.com/-ymMAMBus87Y/AAAAAAAAAAI/AAAAAAAAAAA/dkTJASKtEp4/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="The-Art-of-Guitar",
        url="plugin://plugin.video.youtube/user/PitchfeverAcademy/",
        thumbnail="https://yt3.ggpht.com/-N3rRevMqvTc/AAAAAAAAAAI/AAAAAAAAAAA/7ZmUK9fvLuI/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
       
    plugintools.add_item( 
        #action="", 
        title="Music is Win",
        url="plugin://plugin.video.youtube/channel/UCshiNtfJ7Dj3nlh41a6M-kg/playlists/",
        thumbnail="https://yt3.ggpht.com/-sPtteb8ZlvU/AAAAAAAAAAI/AAAAAAAAAAA/CHIkPrlQWCA/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="GuitarZoom.com",
        url="plugin://plugin.video.youtube/channel/UCpuRSQ79vgNyg2H4M_JVFew/playlists/",
        thumbnail="https://yt3.ggpht.com/-MnBmUASpw70/AAAAAAAAAAI/AAAAAAAAAAA/apQY4Y0GlgY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
                
    plugintools.add_item( 
        #action="", 
        title="Guitar Tricks",
        url="plugin://plugin.video.youtube/user/Guitartricks/",
        thumbnail="https://yt3.ggpht.com/-G1Fdflt3Od0/AAAAAAAAAAI/AAAAAAAAAAA/p9r8ykQCBQI/s100-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="LoremaryluGT",
        url="plugin://plugin.video.youtube/user/loremarylugt/",
        thumbnail="https://yt3.ggpht.com/-L4Z7tEQfvLU/AAAAAAAAAAI/AAAAAAAAAAA/tcEVhiRPXPs/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="EricBlackmonGuitar",
        url="plugin://plugin.video.youtube/user/EricBlackmonGuitar/",
        thumbnail="https://yt3.ggpht.com/-1LYFNwMrM40/AAAAAAAAAAI/AAAAAAAAAAA/6Nsk4qlvSOU/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
				
    plugintools.add_item( 
        #action="", 
        title="好和弦",
        url="plugin://plugin.video.youtube/channel/UCVXstWyJeO6No3jYELxYrjg/",
        thumbnail="https://yt3.ggpht.com/-hz6hRRT9waU/AAAAAAAAAAI/AAAAAAAAAAA/w1JVkBPKBGQ/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="嘎老師(唱歌)",
        url="plugin://plugin.video.youtube/channel/UCJdMrdkCXs5FkR3DHlor81w/",
        thumbnail="https://yt3.ggpht.com/a-/AN66SAzE4oFWMFoNayQWRo24ygpTOwqs8IyLQed4qg=s288-mo-c-c0xffffffff-rj-k-no",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="The Ukulele Teacher",
        url="plugin://plugin.video.youtube/channel/UC1HlihY-iNtOemAlYQq3GXQ/",
        thumbnail="https://yt3.ggpht.com/-7PP4UcxiVCc/AAAAAAAAAAI/AAAAAAAAAAA/rKKKi4-cc6M/s100-c-k-no-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Chinaguitarsceptic",
        url="plugin://plugin.video.youtube/user/Chinaguitarsceptic/",
        thumbnail="https://yt3.ggpht.com/-ggZXfHNcnFw/AAAAAAAAAAI/AAAAAAAAAAA/MKdY5Jl1aT4/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="How To INSTANTLY Solo In Any Key",
		url="plugin://plugin.video.youtube/play/?video_id=tC-Ne_IriNc&t=1232s",
        thumbnail="",
        folder=False )		
		
run()